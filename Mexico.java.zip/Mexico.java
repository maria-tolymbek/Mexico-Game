/* A program to simulate the game of Mexico between Giulia and David
 * 
 * Maria Tolymbek, 260685958 
 */

import java.lang.Math;

public class Mexico{
  //declaring the main method 
  public static void main(String[] args){
    
  // initializing variables g and d to invoke the method getWinner(giulia, david)
    playMexico(6.0, 2.0); 
  }
  
  // a method to simulate the outcome of a roll of one six-sided dice
  public static int diceRoll(){
    int score = (int)(Math.random()*(6-1+1)+1); 
    
  /* Brackets are around (Math.random()*6) so the integer value between 0 and 6 is returned
   * To obtain a random integer between 2 values, inclusively, we must use (max-min+1)+1 */
    return score;
  }
  
  // a method to obtain the score of the two rolls
  public static int getScore(int x, int y){
    int max = x; //storing x as a temporary variable (max) and comparing x and y in relation to max.
    if (y>=max)
      max=y;
    
    int min = y; //similarly with temporary variable (min)
    if(x<=min)
      min = x;
    
    //concatenating the two values by adding "" (String converted to int)
    int score = Integer.parseInt(max + ""+ min);
   
    return score;
  }
    
  // a method to simulate one round of a game
  public static int playOneRound(String name){

  //assigning values to diceRoll() called roll1 and roll2
  //storing getScore in int variable (score)
    int roll1 = diceRoll();
    int roll2 = diceRoll();
    int score = getScore(roll1,roll2); 
    
    //print statement showing the values of the two dice rolls and individual scores
    System.out.println(name + " rolled: " + roll1 + " " + roll2);  //how do we get only to use input from last time?
    System.out.println(name + "'s score is: " + getScore(roll1,roll2));
    
    return score;
  }
  
  // a method to obtain the winner of each round of a game using if and else-if conditional statements
  public static String getWinner(int giulia, int david){ 
     
    if (giulia == david){   // if Giulia's score is equal to David's score, return "tie"
      return "tie";
    } 
    else if (giulia==21){   // 21 is the highest possible score, so the condition will be evaluated before the others
      return "Giulia";
    }
    else if (david ==21){
      return "David";
    } 
    // A doubles score is the next highest possible score, so this condition is evaluated next
    else if ((giulia%11==0)||(david%11==0)){   
      
        if ((giulia%11==0) && (david%11==0)){ // in the event that both scores are doubles, the highest score of the two doubles is returned  
          if (giulia>david) {
            return "Giulia";
          }
          else {
            return "David";
          }
        }
    // if a doubles score is achieved by either or, this condition is evaluated
         else if (giulia%11==0){  
           return "Giulia";
         }
         else if (david%11==0){
           return "David";
         }
    }
    
    // finally, the mixed roll is evaluated, ranked according to its numerical value
         else if (giulia>david){
           return "Giulia";
         }
         else if (david>giulia){
           return "David";
         }
    
    return "";  //return type String
  }
  
  // a method to determine if the game can be played, that is if the base bet and buy-in are set correctly
  public static boolean canPlay(double buyin, double bet){
    
    //condition to check that the bet is no larger than the buy in
    if (bet>buyin){
      System.out.println("Insufficient funds. The game cannot be played.");
      return false;
    } 
    
   // When the bet is no larger than the buyin, the method returns true if the buyin is a positive multiple of the bet
   // The while loop and if statement is used to evaluate the conditioni
    while (bet<=buyin){
      if (buyin%bet ==0 && (buyin/bet)>0){   // buyin is a positive multiple of bet
        System.out.println("The game can be played");
        return true;
      } 
      else{
        System.out.println("Insufficient funds. The game cannot be played.");
      return false;
      }
    }
  return true;
  }
  
  // a method to simulate the game
  public static void playMexico (double buyin, double bet){   
    
    canPlay(buyin, bet);  //The buy-in and bet value is retrieved from the input of playMexico
    System.out.println("Each player starts with $ " + buyin);
    System.out.println("");
    
    int giulia, david; //declaring variables of the scores of Giulia and David
       
        double giuliaamount, davidamount; // declaring and initializing Giulia and David's amount ($) equal to the buyin
        giuliaamount=buyin;
        davidamount=buyin;
        
        int r = 1; //initializing the number of the round
        
    // Under the condition that Giulia and David's money is no less than $0.0, the game can play 
    while (giuliaamount>=0.0 && davidamount>=0.0){  
      
      System.out.println("Round " + r);
      System.out.println(" ");
    
      // storing Giulia's and David's scores as int values giulia and david, respectively
      giulia = playOneRound("Giulia"); 
      david = playOneRound("David");
      
      String winner = getWinner(giulia, david); // assigning winner to the String name
     
      /*Under the situation that the winner of the round is David (String comparison), the bet value is deducted 
       * from Giulia's amount and vice versa for Giulia if she is the winner. 
       * The loop continues until someone reaches $0.0 using the boolean || operator in the if statement. The winner of 
       the game is printed and the method terminated*/
        
      if (winner.equals("David")){
        System.out.println("David wins this round"); 
        giuliaamount-=bet; 
        System.out.println("Giulia has $ " + giuliaamount + " left" + "\n"); 
      } 
        
      else if (winner.equals("Giulia")){
        System.out.println("Giulia wins this round");
        davidamount-=bet;
        System.out.println("David has $ " + davidamount + " left" + "\n");
      }
      else if (winner.equals("tie")){
        System.out.println("It's a tie! Roll again! " + "\n");
      }
      
      if (giuliaamount==0.0 || davidamount==0.0){
        System.out.println(winner + " won the game!");
        return;
      }
    r++;  // the number of the round goes up by 1 each iteration
    }
  }
}
    
        
   